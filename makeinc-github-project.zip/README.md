# Make.Inc — Digital Growth Hub

A responsive, dark-luxury dashboard concept for Make.Inc Design + Build. Built with plain HTML, CSS and JavaScript, so it can be hosted easily on GitHub Pages.

## Preview locally
1. Download or clone this repository.
2. Keep `index.html` and the `assets` folder together.
3. Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a repository on GitHub (for example, `makeinc-growth-hub`).
2. Upload `index.html`, `README.md`, and the `assets` folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish and open the URL shown on the Pages settings screen.

## Important about Instagram
This is a front-end prototype. The dashboard intentionally shows placeholders rather than fabricated live analytics. A real connection requires Meta/Instagram API setup, OAuth, the required account permissions, and a secure backend to protect access tokens. Never put Meta app secrets or long-lived access tokens in front-end JavaScript or a public GitHub repository.

## Customize
- Replace `assets/makeinc-logo.jpg` with your preferred logo file (keep the same filename, or update the image paths in `index.html`).
- Update Instagram profile links and brand copy.
- Connect the action handlers to a backend when ready.
